- Go to menu *Invoicing > Configuration > Settings > Invoicing*, under *Electronic Invoices*.
- Check the value of *Include UBL XML in Invoice Email*, set to `True` if you want to include
  the UBL XML in the attachments when sending the invoice by email.
