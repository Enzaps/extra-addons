# © 2016-2017 Akretion (Alexis de Lattre <alexis.delattre@akretion.com>)
# Copyright 2019 Onestein (<https://www.onestein.eu>)
# Copyright 2020 Jacques-Etienne Baudoux (BCIM) <je@bcim.be>
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

import logging
import mimetypes
from io import BytesIO

from lxml import etree

from odoo import _, api, models
from odoo.exceptions import UserError
from odoo.tools import file_open, float_is_zero, float_round

logger = logging.getLogger(__name__)

try:
    from PyPDF2 import PdfFileReader, PdfFileWriter
    from PyPDF2.generic import NameObject
except ImportError:
    logger.debug("Cannot import PyPDF2")


class BaseUbl(models.AbstractModel):
    _inherit = "base.ubl"
    _description = "Common methods to generate and parse UBL XML files"

    # ==================== METHODS TO GENERATE UBL files


    @api.model
    def _ubl_add_item(
        self,
        name,
        iline,
        product,
        parent_node,
        ns,
        type_="purchase",
        seller=False,
        version="2.1",
    ):
        """Beware that product may be False (in particular on invoices)"""
        assert type_ in ("sale", "purchase"), "Wrong type param"
        assert name, "name is a required arg"
        item = etree.SubElement(parent_node, ns["cac"] + "Item")
        product_name = False
        seller_code = False
        if product:
            if type_ == "purchase":
                if seller:
                    sellers = product._select_seller(
                        partner_id=seller, quantity=0.0, date=None, uom_id=False
                    )
                    if sellers:
                        product_name = sellers[0].product_name
                        seller_code = sellers[0].product_code
            if not seller_code:
                seller_code = self._ubl_get_seller_code_from_product(product)
            if not product_name:
                variant = ", ".join(product.attribute_line_ids.mapped("value_ids.name"))
                product_name = (
                    variant and "{} ({})".format(product.name, variant) or product.name
                )
        description = etree.SubElement(item, ns["cbc"] + "Description")
        description.text = name
        name_node = etree.SubElement(item, ns["cbc"] + "Name")
        name_node.text = product_name or name.split("\n")[0]
        #######code added########################################



        name_class_node = etree.SubElement(item, ns["cac"] + "ClassifiedTaxCategory")
        name_class_id = etree.SubElement(name_class_node, ns["cbc"] + "ID")
        name_class_id.text = iline.vat_category
        name_class_Percent = etree.SubElement(name_class_node, ns["cbc"] + "Percent")
        name_class_Percent.text = str(sum(iline.tax_ids.mapped('amount')))
        tax_class_node = etree.SubElement(name_class_node, ns["cac"] + "TaxScheme")
        tax_class_node_id = etree.SubElement(tax_class_node, ns["cbc"] + "ID")
        tax_class_node_id.text = "VAT"


    #################################################################################################

        # if seller_code:
        #     seller_identification = etree.SubElement(
        #         item, ns["cac"] + "SellersItemIdentification"
        #     )
        #     seller_identification_id = etree.SubElement(
        #         seller_identification, ns["cbc"] + "ID"
        #     )
        #     seller_identification_id.text = seller_code
        # if product:
        #     if product.barcode:
        #         std_identification = etree.SubElement(
        #             item, ns["cac"] + "StandardItemIdentification"
        #         )
        #         std_identification_id = etree.SubElement(
        #             std_identification,
        #             ns["cbc"] + "ID",
        #             schemeAgencyID="6",
        #             schemeID="GTIN",
        #         )
        #         std_identification_id.text = product.barcode
        #     # I'm not 100% sure, but it seems that ClassifiedTaxCategory
        #     # contains the taxes of the product without taking into
        #     # account the fiscal position
        #     if type_ == "sale":
        #         taxes = product.taxes_id
        #     else:
        #         taxes = product.supplier_taxes_id
        #     if taxes:
        #         for tax in taxes:
        #             self._ubl_add_tax_category(
        #                 tax,
        #                 item,
        #                 ns,
        #                 node_name="ClassifiedTaxCategory",
        #                 version=version,
        #             )
        #     for attribute_value in product.attribute_line_ids.mapped("value_ids"):
        #         item_property = etree.SubElement(
        #             item, ns["cac"] + "AdditionalItemProperty"
        #         )
        #         property_name = etree.SubElement(item_property, ns["cbc"] + "Name")
        #         property_name.text = attribute_value.attribute_id.name
        #         property_value = etree.SubElement(item_property, ns["cbc"] + "Value")
        #         property_value.text = attribute_value.name

