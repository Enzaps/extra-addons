* Alexis de Lattre <alexis.delattre@akretion.com>
* Raphaël Valyi
* Stefan Rijnhart (Therp)
* Alexandre Fayolle
* Stéphane Bidoul <stephane.bidoul@acsone.eu>
* Danimar Ribeiro
* Angel Moya <angel.moya@domatix.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * Carlos Dauden
  * Víctor Martínez
* `DynApps <https://www.dynapps.be>`_:

  * Raf Ven <raf.ven@dynapps.be>
* Marçal Isern <marsal.isern@qubiq.es>
