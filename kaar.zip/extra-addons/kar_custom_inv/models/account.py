from odoo import fields, models,api,_

class AccountMove(models.Model):
    _inherit = "account.move"
    custom_invoice_no = fields.Char('Custom Invoice No')
