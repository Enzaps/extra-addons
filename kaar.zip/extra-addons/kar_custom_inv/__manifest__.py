{
    'name': "Kar Custom Invoice",
    'author':
        'ENZAPPS',
    'summary': """
This module is for Kar Custom Invoice.
""",

    'description': """
        This module is for Kar Custom Invoice.
    """,
    'website': "",
    'category': 'base',
    'version': '14.0',
    'depends': ['base','account'],
    "images": ['static/description/icon.png'],
    'data': [
        'views/account_move.xml'
    ],
    'demo': [
    ],
    'qweb': [
    ],
    'installable': True,
    'application': True,
}
