This module requires the Python library `factur-x <https://github.com/akretion/factur-x>`__ developped by Akretion. To install it, run:

.. code::

  sudo pip3 install --upgrade factur-x
