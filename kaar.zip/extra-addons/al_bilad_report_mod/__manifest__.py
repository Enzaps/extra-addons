{
    "name": "Al Bilad Tax Invoice Report",
    "version": "14.0.1.2.1",
    "category": "Accounting",
    "license": "",
    "summary": "Al Bilad Tax Invoice",
    "author": "Enzapps Private Limited",
    "website": "https://www.enzapps.com",
    "depends": ["base","account",'uom_unece','base_unece','account_tax_unece','base_vat_sanitized','onchange_helper','base_iban','base_bank_from_iban','base_business_document_import','account_invoice_import','base_ubl_payment','account_invoice_import_ubl','account_invoice_ubl'],
    "data": [
        'views/albilad_invoice.xml',
        'report/al_bilad_report_view.xml',
        'report/report.xml',
    ],
    "qweb": [
    ],
    "installable": True,
}