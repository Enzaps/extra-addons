To use this module, you need to:

#. Go to Partner
#. Click *Bank Account(s)* in "Sales & Purchases" page.
#. Create/modify IBAN bank account.
#. When you put the bank account number, module extracts bank digits from the format of the country, and try to match an existing bank by country and code.
#. If there's a match, the bank is selected automatically.
