# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': 'Kaar Invoice amount',
    'author': 'Enzapps',
    'category': 'Accounting',
    'description': """
=======================================================
    """,
    'license': '',
    'depends': ['account'],
    'data': [],
    'qweb': [],
    "installable": True,
}
