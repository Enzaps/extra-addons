from odoo import models, fields, api, _


class AccountMove(models.Model):
    _inherit = 'account.move'
    _order = "invoice_date desc"

    def amount_words(self):
        return self.currency_id.amount_to_text(self.amount_total)
