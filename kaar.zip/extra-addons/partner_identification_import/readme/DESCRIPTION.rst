Glue module between base_business_document_import and partner_identification (in OCA/partner-contact)

Allow to define extra partner ID (thanks to partner_identification) and match
the partner using for exemple the UBL PartyIdentification/ID
