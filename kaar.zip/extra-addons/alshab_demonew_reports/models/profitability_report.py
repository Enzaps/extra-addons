from odoo import models,fields,api

class ProfitabilityReport(models.Model):
    _name = 'profitability.report'

    bill = fields.Many2one('account.move', "Bill",domain=[('move_type', '=', 'in_invoice')])
    product = fields.Many2one('product.product', "Product")
    sale = fields.Many2one('account.move', "Sales",domain=[('move_type', '=', 'out_invoice')])
    type = fields.Selection([('bill_wise', 'Bill Wise'),('item_wise','Item Wise'),('sales_wise','Sales Wise')])
    profit = fields.One2many('profitability.new.report','conn')

    @api.onchange('bill','product','sale', 'type')
    def onchange_profitability(self):


        if self.type =='item_wise':

            item_id = self.env['product.product'].search([('id', '=', self.product.id)])
            data = []
            values = (0, 0, {
                'account': item_id.property_account_income_id.id,
                'sales_amount': item_id.list_price,
                'cost_amount': item_id.standered_price,
                'profit_loss': item_id.amount_total
            })
            data.append(values)
            self.profit = None
            self.profit = data


class ProfitabilityNewReport(models.Model):
    _name = 'profitability.new.report'

    conn = fields.Many2one('profitability.report')
    date = fields.Date("Date")
    reference_no = fields.Char("Reference No")
    account = fields.Many2one('account.account',"Account")
    sales_amount = fields.Float("Sales Amount")
    cost_amount = fields.Float("Cost Amount")
    profit_loss = fields.Float("Profit and Loss")