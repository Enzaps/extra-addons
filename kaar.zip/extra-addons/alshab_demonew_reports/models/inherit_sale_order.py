from odoo import models,fields,api
from datetime import date

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    entry_date = fields.Date(default=date.today())
    rig = fields.Char(String="RIG")
    po_number = fields.Char('PO Number')
    po_date = fields.Date('PO Date')


def action_confirm(self):
        super(SaleOrder, self).action_confirm()
        for i in self.order_line:
            self.env['pending.sale.order'].create({
                'product_name': i.product_id.id,
                'part_no': i.product_id.default_code,
                'manufacturer_name': i.product_id.manufacturer_name,
                'reference_no': i.product_id.default_code,
                'buying_rate': i.supplier_price,
                'selling_rate': i.price_unit,
                'so_no': self.id,
                'so_date': self.entry_date,
                'supplier': i.supplier.id,
                'supplier_po': i.supplier_po,
                'entry_date' : self.entry_date,
                'customer_name': self.partner_id.id,
                'customer_po': self.po_number,
                'po_date': self.po_date,
                'rig': self.rig,
                'qty_ordered': i.product_uom_qty,
                'balance_qty': i.product_uom_qty,
                'remark': i.remarks,
                'availability': i.availability,
            })

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    # supplier_po = fields.Char("Supplier Po")

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    manufacturer_name = fields.Char("Manufacturer Name")


class StockImmediateTransfer(models.TransientModel):
    _inherit = 'stock.immediate.transfer'

    def process(self):
        res = super(StockImmediateTransfer, self).process()
        for line in self.pick_ids.move_ids_without_package:
            so_id = self.env["sale.order"].search([('name', '=', self.pick_ids.origin)])
            pick_ids = self.env["pending.sale.order"].search([('so_no', '=', so_id.id), ('product_name','=', line.product_id.id)])
            if pick_ids:
                pick_ids.write({
                    'location': line.location_id.id,
                    'qty_delivered': line.quantity_done,
                    'balance_qty': pick_ids.qty_ordered - line.quantity_done,
                })
        return res

class StockPicking(models.Model):
    _inherit = 'stock.picking'
    def button_validate(self):
        res = super(StockPicking, self).button_validate()

        for line in self.move_ids_without_package:
            for sale in self.sales_ids:
                # so_id = self.env["sale.order"].search([('id', '=', self.corresponding_so_po)])
                so_id = self.env["sale.order"].search([('id', '=', sale.id)])
                pick_ids = self.env["pending.sale.order"].search(
                    [('so_no', '=', so_id.id), ('product_name', '=', line.product_id.id)])
                if pick_ids:
                    i=0
                    for pick in pick_ids:
                        i +=1;
                        if i ==1:
                            done = pick.qty_delivered + line.quantity_done
                            pick_ids.write({
                                'location': line.location_id.id,
                                'qty_delivered': pick.qty_delivered + line.quantity_done,
                                'balance_qty': pick.qty_ordered -done,
                            })
        return res


class SaleAdvancePaymentInv(models.TransientModel):
    _inherit = 'sale.advance.payment.inv'

    def create_invoices(self):
        res = super(SaleAdvancePaymentInv, self).create_invoices()
        sale_orders = self.env['sale.order'].browse(self._context.get('active_ids', []))
        for inv in sale_orders.invoice_ids:
                pending = self.env["pending.sale.order"].search([('so_no', '=', sale_orders.name)])
                if pending:
                    pending.write({
                        'inv_no': inv.id,
                        'inv_date': inv.invoice_date,
                        })
        return res



class AccountMove(models.Model):
    _inherit = "account.move"

    def action_post(self):
        res = super(AccountMove, self).action_post()
        order = self.env["pending.sale.order"].search([('inv_no', '=', self.id)])
        for inv_order in order:
            inv_order.inv_date=self.invoice_date
        return res












