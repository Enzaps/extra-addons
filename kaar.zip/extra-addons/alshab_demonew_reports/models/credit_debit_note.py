from odoo import models, fields, api,_


class CreditDebit(models.Model):
    _name = 'credit.debit'

    from_date = fields.Date("From Date")
    to_date = fields.Date("To Date")
    type = fields.Selection([('credit', 'Credit'), ('debit', 'Debit')], copy=False,
                            string="Type", default='credit')
    credit_debit_report = fields.One2many('credit.debit.note', 'note')
    name = fields.Char("Name", index=True, default=lambda self: _('New'))


    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            if 'company_id' in vals:
                vals['name'] = self.env['ir.sequence'].with_context(force_company=vals['company_id']).next_by_code(
                    'credit.debit') or _('New')
            else:
                vals['name'] = self.env['ir.sequence'].next_by_code('credit.debit') or _('New')
        return super(CreditDebit, self).create(vals)

    @api.onchange('from_date', 'to_date', 'type')
    def onchange_from_date(self):
        if self.from_date and self.to_date:
            if self.type == 'credit':
                datas = self.env['account.move'].search(
                    [('invoice_date', '>=', self.from_date), ('move_type', '=', 'out_refund'),
                     ('invoice_date', '<=', self.to_date)])
                data = []
                for line in datas:
                    for i in line.invoice_line_ids:
                        # if line.move_type == 'out_invoice':
                        reverse_line = line.reversed_entry_id.invoice_line_ids.filtered(
                            lambda a: a.product_id == i.product_id)
                        values = (0, 0, {
                            'date': line.invoice_date,
                            'reference_no': line.name,
                            'party_name': line.partner_id.name,
                            'invoice_no': line.name,
                            'invoiced_qty': reverse_line[0].quantity,
                            'return_qty': i.quantity,
                            'taxable_amount': line.amount_untaxed,
                            'output_vat': line.amount_tax,
                            'gross_amount': line.amount_total,
                            'reason_for_return': line.ref
                        })
                    data.append(values)
            else:
                datas = self.env['account.move'].search(
                    [('invoice_date', '>=', self.from_date), ('move_type', '=', 'in_refund'),
                     ('invoice_date', '<=', self.to_date)])
                data = []
                for line in datas:
                    quantity = 0
                    for i in datas.invoice_line_ids:
                        # if line.move_type == 'out_invoice':
                        reverse_line = line.reversed_entry_id.invoice_line_ids.filtered(
                            lambda a: a.product_id == i.product_id)
                        quantity += reverse_line.quantity
                    values = (0, 0, {
                        'date': line.invoice_date,
                        'reference_no': line.name,
                        'party_name': line.partner_id.name,
                        'invoice_no': line.name,
                        'invoiced_qty': quantity,
                        'return_qty': sum(line.invoice_line_ids.mapped('quantity')),
                        'taxable_amount': line.amount_untaxed,
                        'output_vat': line.amount_tax,
                        'gross_amount': line.amount_total,
                        'reason_for_return': line.ref
                    })
                data.append(values)

            self.credit_debit_report = None
            self.credit_debit_report = data


class CreditDebitNote(models.Model):
    _name = 'credit.debit.note'

    note = fields.Many2one('credit.debit')
    date = fields.Date("Date")
    reference_no = fields.Char("Ref No")
    party_name = fields.Char("Party Name")
    invoice_no = fields.Char("INV No")
    invoiced_qty = fields.Char("INV Qty")
    return_qty = fields.Char("Return Qty")
    taxable_amount = fields.Float("Taxable Amount")
    output_vat = fields.Float("Output Vat")
    gross_amount = fields.Float("Gross amount")
    reason_for_return = fields.Text("Reason")


class AccountMove(models.Model):
    _inherit = 'account.move'

    return_qty = fields.Char("Return Qty")
    reason_for_return = fields.Text("Reason For Return")
