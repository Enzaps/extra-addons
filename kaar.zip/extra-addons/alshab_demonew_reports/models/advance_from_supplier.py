from odoo import models,fields,api


class AdvanceSupplier(models.Model):
    _name = 'advance.supplier'

    from_date = fields.Date("From Date")
    to_date = fields.Date("To date")
    supplier = fields.One2many('advance.from.supplier','conn')

    @api.onchange('from_date', 'to_date')
    def onchange_advance_supplier(self):
        datas = self.env['purchase.order'].search(
            [('entry_date', '>=', self.from_date), ('entry_date', '<=', self.to_date),('amnt_received_in_advance', '!=', 0.0)])
        data = []
        for line in datas:
            for i in line.order_line:
                values = (0, 0, {
                    'date': line.entry_date,
                    'party_name': line.partner_id.name,
                    'purchase_order_no': line.name,
                    'purchase_order_date': line.entry_date,
                    'qty_ordered': i.product_uom_qty,
                    'rate': i.price_unit,
                    'tot_amnt':line.amount_total,
                    'amnt_received_in_advance':line.amnt_received_in_advance,
                    'due_date':line.entry_date
                })
                data.append(values)
            self.supplier = None
            self.supplier = data


class AdvanceFromSupplier(models.Model):
    _name = 'advance.from.supplier'

    conn = fields.Many2one('advance.supplier')
    date = fields.Date("Date")
    party_name = fields.Char("Party Name")
    purchase_order_no = fields.Char("Purchase Order No")
    purchase_order_date = fields.Date("Purchase Order Date")
    qty_ordered = fields.Char("Qty Ordered")
    rate = fields.Float("Rate")
    tot_amnt = fields.Float("Tot Amnt")
    amnt_received_in_advance = fields.Float("Amnt Received In Advance")
    due_date = fields.Date("Due Date")

class SaleOrder(models.Model):
    _inherit = 'purchase.order'

    amnt_received_in_advance = fields.Float("Amnt Received In Advance")

class AccountPayment(models.Model):
    _inherit = 'account.payment'

    def action_post(self):
        res = super(AccountPayment, self).action_post()
        if self.purchase_order_id:
            self.purchase_order_id.amnt_received_in_advance = self.amount
        else:
         return res


