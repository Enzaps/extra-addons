from odoo import models,fields,api

class PurchaseOrderReport(models.Model):
    _name = 'purchase.order.report'

    from_date = fields.Date("From Date")
    to_date = fields.Date("to Date")
    purchase = fields.One2many('purchase.report.form','conn')

    @api.onchange('from_date', 'to_date')
    def onchange_from_date(self):
        if self.from_date and self.to_date:
            datas = self.env['account.move'].search(
                [('invoice_date', '>=', self.from_date), ('invoice_date', '<=', self.to_date)])
            data = []
            for line in datas:
                order = self.env['sale.order'].search([('invoice_ids', '=', line.name)])
                picking = self.env['sale.order'].search([('invoice_ids', '=', line.name)]).picking_ids
                if line.move_type == 'in_invoice' :
                    values = (0, 0, {
                        'entry_date': line.invoice_date,
                        'system_date': line.invoice_date_due,
                        'invoice_no': line.name,
                        'party_name': line.partner_id.name,
                        'customer_vat_no': line.partner_id.vat,
                        'sale_order_no': order,
                        'delivery_note': picking.name,
                        'vat': line.invoice_line_ids.tax_ids,
                        'taxable_amount': line.amount_untaxed,
                        'output_vat': line.amount_tax,
                        'gross_amount': line.amount_total,
                    })
                    data.append(values)
                self.purchase = None
                self.purchase = data



class PurchaseReport(models.Model):
    _name = 'purchase.report.form'

    conn = fields.Many2one('purchase.order.report')
    entry_date = fields.Date("Entry Date")
    system_date = fields.Date("System Date")
    invoice_no = fields.Char('INV No')
    party_name = fields.Char("Party Name")
    customer_vat_no = fields.Char("Customer Vat No")
    sale_order_no = fields.Many2one('sale.order', "SO No")
    delivery_note = fields.Char("Delivery Note")
    vat = fields.Many2one('account.tax', "VAT")
    taxable_amount = fields.Float("Taxable Amount")
    output_vat = fields.Char("Output Vat")
    gross_amount = fields.Float("Gross Amount")