from odoo import fields,models,api

class OutstandingDelivery(models.Model):
    _name = 'outstanding.delivery'

    product_name = fields.Many2one('product.product',"Product Name")
    part_no = fields.Char("Part No")
    entry_date = fields.Date("Entry Date")
    manufacturer_name = fields.Char("Manufacturer Name")
    reference_no = fields.Char("Reference No")
    buying_rate = fields.Float("Buying rate")
    selling_rate = fields.Float("Selling Rate")
    so_no = fields.Many2one('sale.order',"SO No")
    so_date = fields.Date("SO Date")
    supplier = fields.Many2one('res.partner',"Supplier")
    supplier_po = fields.Char("Suppier PO#")
    location = fields.Many2one('stock.location',"Location")
    customer_name = fields.Many2one('res.partner',"Customer Name")
    customer_po = fields.Char("Customer PO#")
    po_date = fields.Date("PO Date")
    rig = fields.Char("Rig#")
    qty_ordered = fields.Float("Qty Ordered")
    qty_delivered = fields.Float("Qty Delivered")
    balance_qty = fields.Float("Balance Qty")
    remark = fields.Text("REMARK")
    availability = fields.Char("Availability")
    delivery_challan_no = fields.Char("Delivery Challan No")
    inv_no = fields.Many2one('account.move',"INV No")
    inv_date = fields.Char("INV Date")