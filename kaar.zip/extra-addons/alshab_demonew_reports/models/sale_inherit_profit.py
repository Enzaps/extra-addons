from odoo import models,fields,api

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    profit = fields.Float("Profit", compute='_compute_profit')

    def _compute_profit(self):
        for sale in self:
            total = 0
            for line in sale.order_line:
                total += line.margin
            sale.profit = total

class AccountMove(models.Model):
    _inherit = 'account.move'

    profit = fields.Float("Profit",compute='comput_invoice')

    def comput_invoice(self):
        for i in self:
            total = 0
            for line in i.invoice_line_ids:
                margin = line.price_subtotal-(line.quantity*line.product_id.standard_price)
                total += margin
            i.profit = total



