from odoo import models,fields,api,_


class SalesInvoiceForm(models.Model):
    _name = 'sales.invoice.form'

    from_date = fields.Date("From Date")
    to_date = fields.Date("to Date")
    invoice = fields.One2many('sales.invoice','conn')
    name = fields.Char("Name", index=True, default=lambda self: _('New'))


    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            if 'company_id' in vals:
                vals['name'] = self.env['ir.sequence'].with_context(force_company=vals['company_id']).next_by_code(
                    'sales.invoice.form') or _('New')
            else:
                vals['name'] = self.env['ir.sequence'].next_by_code('sales.invoice.form') or _('New')
        return super(SalesInvoiceForm, self).create(vals)

    @api.onchange('from_date', 'to_date')
    def onchange_from_date(self):
        if self.from_date and self.to_date:
            datas = self.env['account.move'].search(
                [('invoice_date', '>=', self.from_date),('invoice_date', '<=', self.to_date)])
            data = []
            for line in datas:
                delivery_note = ''
                order=self.env['sale.order'].search([('invoice_ids', '=',line.name)])
                picking=self.env['sale.order'].search([('invoice_ids', '=',line.name)]).picking_ids
                if picking:
                    if order.picking_ids:
                        for e in order.picking_ids:
                            delivery_note=e.name+','
                else:
                    ref_inv =self.env['alshab.inventorys'].search([('delivery_invoice_ids', '=',line.name)])
                    if ref_inv.picking_ids:
                        for pick in ref_inv.picking_ids:
                            delivery_note = pick.name+','
                if line.move_type == 'out_invoice':
                    values = (0, 0, {
                        'entry_date': line.invoice_date,
                        'system_date': line.invoice_date_due,
                        'invoice_no': line.name,
                        'party_name': line.partner_id.name,
                        'customer_vat_no': line.partner_id.vat,
                        'sale_order_no': order,
                        'delivery_note': delivery_note,
                        'vat': line.invoice_line_ids.tax_ids,
                        'taxable_amount': line.amount_untaxed,
                        'output_vat': line.amount_tax,
                        'gross_amount': line.amount_total,
                    })
                    data.append(values)
                self.invoice = None
                self.invoice = data

class sales_invoice(models.Model):
    _name = 'sales.invoice'

    conn = fields.Many2one('sales.invoice.form')
    entry_date = fields.Date("Entry Date")
    system_date = fields.Date("System Date")
    invoice_no = fields.Char('INV No')
    party_name = fields.Char("Party Name")
    customer_vat_no = fields.Char("Customer Vat No")
    sale_order_no = fields.Many2one('sale.order',"SO No")
    delivery_note = fields.Char("Delivery Note")
    vat = fields.Many2one('account.tax',"VAT")
    taxable_amount = fields.Float("Taxable Amount")
    output_vat = fields.Char("Output Vat")
    gross_amount = fields.Float("Gross Amount")


class AccountMove(models.Model):
    _inherit = "account.move"

    remark = fields.Text("Remark")

    sale_order = fields.Many2one('sale.order')

