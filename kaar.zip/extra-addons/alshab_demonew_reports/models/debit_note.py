from odoo import models, fields, api, _


class DebitNote(models.Model):
    _name = 'debit.note'

    from_date = fields.Date("From Date")
    to_date = fields.Date("To Date")
    debit = fields.One2many('debit.note.report', 'conn')
    name = fields.Char("Name", index=True, default=lambda self: _('New'))

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            if 'company_id' in vals:
                vals['name'] = self.env['ir.sequence'].with_context(force_company=vals['company_id']).next_by_code(
                    'debit.note') or _('New')
            else:
                vals['name'] = self.env['ir.sequence'].next_by_code('debit.note') or _('New')
        return super(DebitNote, self).create(vals)

    @api.onchange('from_date', 'to_date')
    def onchange_debit_note(self):
        datas = self.env['account.move'].search(
            [('invoice_date', '>=', self.from_date), ('invoice_date', '<=', self.to_date),
             ('move_type', '=', 'in_refund')])
        data = []
        for line in datas:
            quantity = 0
            for i in datas.invoice_line_ids:
                # if line.move_type == 'out_invoice':
                reverse_line = line.reversed_entry_id.invoice_line_ids.filtered(
                    lambda a: a.product_id == i.product_id)
                quantity += reverse_line.quantity
            values = (0, 0, {
                'date': line.invoice_date,
                'ref_no': line.ref,
                'party_name': line.partner_id.name,
                'inv_no': line.name,
                'inv_qty': quantity,
                'return_qty': sum(line.invoice_line_ids.mapped('quantity')),
                'taxable_amnt': line.amount_untaxed,
                'input_vat': line.amount_tax,
                'gross_amnt': line.amount_total,
                'reason_for_return': line.ref,
            })
            data.append(values)
        self.debit = None
        self.debit = data


class DebitNoteReport(models.Model):
    _name = 'debit.note.report'

    conn = fields.Many2one('debit.note')
    date = fields.Date("Date")
    ref_no = fields.Char("Ref No")
    party_name = fields.Char("Party Name")
    inv_no = fields.Char("INV No")
    inv_qty = fields.Char("INV Qty")
    return_qty = fields.Char("Return Qty")
    taxable_amnt = fields.Float("Taxable Amnt")
    input_vat = fields.Float("Input Vat")
    gross_amnt = fields.Float("Gross Amnt")
    reason_for_return = fields.Char("Reason For Return")
