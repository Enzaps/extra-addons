from odoo import models,fields,api

class InvoiceProfit(models.Model):
    _name = 'invoice.profit'

    from_date = fields.Date("From Date")
    to_date = fields.Date("To Date")
    type = fields.Selection([('sale_wise','Sale wise')])
    profit = fields.One2many('invoice.profit.form','conn')

    @api.onchange('from_date', 'to_date')
    def onchange_invoice_profit(self):
        datas = self.env['account.move'].search(
            [('invoice_date', '>=', self.from_date), ('invoice_date', '<=', self.to_date)])
        data = []
        for line in datas:

            if line.move_type == 'out_invoice':



                values = (0, 0, {
                    'inv_no': line.name,
                    'total_invoice': line.amount_total,
                    'profit': line.profit
                })
                data.append(values)
            self.profit = None
            self.profit = data

class InvoiceProfitForm(models.Model):
    _name = 'invoice.profit.form'
    conn = fields.Many2one('invoice.profit')
    inv_no = fields.Char("INV No")
    total_invoice = fields.Float("Tot Inv")
    profit = fields.Char("Profit")