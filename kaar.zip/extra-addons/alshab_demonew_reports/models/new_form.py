from odoo import models,fields,api,_
from datetime import datetime

class NewFormSales(models.Model):
    _name = 'new.form.sales'


    from_date = fields.Date("From Date")
    name = fields.Char("Name", index=True, default=lambda self: _('New'))
    to_date = fields.Date("To date")
    type = fields.Selection([('pending_sale','Pending Sale Order'),('delivery_challan','Delivery Challan')])
    sales_form = fields.One2many('sale.form.one', 'conn')

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            if 'company_id' in vals:
                vals['name'] = self.env['ir.sequence'].with_context(force_company=vals['company_id']).next_by_code(
                    'new.form.sales') or _('New')
            else:
                vals['name'] = self.env['ir.sequence'].next_by_code('new.form.sales') or _('New')
        return super(NewFormSales, self).create(vals)

    @api.onchange('from_date', 'to_date','type')
    def onchange_from_date(self):
        if self.type == 'pending_sale':
            datas = self.env['pending.sale.order'].search([('entry_date', '>=', self.from_date),('entry_date', '<=', self.to_date)])
            data = []
            for line in datas:
                if line.qty_ordered > line.qty_delivered:
                    values = (0, 0, {
                        'product_name': line.product_name.id,
                        'part_no': line.part_no,
                        'entry_date': line.entry_date,
                        'manufacturer_name': line.manufacturer_name,
                        'reference_no': line.reference_no,
                        'buying_rate': line.buying_rate,
                        'selling_rate': line.selling_rate,
                        'so_no': line.so_no.id,
                        'so_date': line.so_date,
                        'supplier': line.supplier.id,
                        'supplier_po': line.supplier_po,
                        'location': line.location.id,
                        'customer_name': line.customer_name.id,
                        'customer_po': line.customer_po,
                        'po_date': line.po_date,
                        'rig': line.rig,
                        'qty_ordered': line.qty_ordered,
                        'qty_delivered': line.qty_delivered,
                        'balance_qty': line.balance_qty,
                        'remark': line.remark,
                        'availability': line.availability,
                    })
                    data.append(values)
            self.sales_form = None
            self.sales_form = data
        else:
            datas = self.env['pending.sale.order'].search(
                [('entry_date', '>=', self.from_date), ('entry_date', '<=', self.to_date)])
            data = []
            for line in datas:
                if line.qty_ordered <= line.qty_delivered:
                    values = (0, 0, {
                        'product_name': line.product_name.id,
                        'part_no': line.part_no,
                        'entry_date': line.entry_date,
                        'manufacturer_name': line.manufacturer_name,
                        'reference_no': line.reference_no,
                        'buying_rate': line.buying_rate,
                        'selling_rate': line.selling_rate,
                        'so_no': line.so_no.id,
                        'so_date': line.so_date,
                        'supplier': line.supplier.id,
                        'supplier_po': line.supplier_po,
                        'location': line.location.id,
                        'customer_name': line.customer_name.id,
                        'customer_po': line.customer_po,
                        'po_date': line.po_date,
                        'rig': line.rig,
                        'qty_ordered': line.qty_ordered,
                        'qty_delivered': line.qty_delivered,
                        'balance_qty': line.balance_qty,
                        'remark': line.remark,
                        'availability': line.availability,
                    })
                    data.append(values)
            self.sales_form = None
            self.sales_form = data





            # sales = self.env['stock.picking'].search([('entry_date', '>=',self.from_date),('entry_date', '<=', self.to_date)])
            # form = []
            # for note in sales:
            #     for i in note.sale_id:
            #         for m in i.order_line:
            #             for h in i.invoice_ids:
            #                 values = (0, 0, {
            #                     'system_date': i.po_date,
            #                     'entry_date': i.entry_date,
            #                     'delivery_challan':note.name,
            #                     'inv_no' : h.name,
            #                     'inv_date':h.invoice_date,
            #                     'customer_po':i.po_number,
            #                     'customer_name':i.partner_id,
            #                     'qty_ordered':m.product_uom_qty,
            #                     'uom':m.product_uom,
            #                     'rate':m.price_unit,
            #                     'amount':m.price_subtotal
            #                 })
            #                 form.append(values)
            #                 self.sales_form = None
            #                 self.sales_form = form




class SaleFormSales(models.Model):
    _name = 'sale.form.one'


    conn = fields.Many2one('new.form.sales')
    product_name = fields.Many2one('product.product', "Product Name")
    system_date = fields.Date("System Date")
    delivery_challan = fields.Char("Delivery Challan")
    part_no = fields.Char("Part No")
    entry_date = fields.Date("Entry Date")
    manufacturer_name = fields.Char("Manufacturer Name")
    reference_no = fields.Char("Reference No")
    buying_rate = fields.Float("Buying rate")
    selling_rate = fields.Float("Selling Rate")
    so_no = fields.Many2one('sale.order', "SO No")
    so_date = fields.Date("SO Date")
    supplier = fields.Many2one('res.partner', "Supplier")
    supplier_po = fields.Char("Suppier PO#")
    location = fields.Many2one('stock.location', "Location")
    customer_name = fields.Many2one('res.partner', "Customer Name")
    customer_po = fields.Char("Customer PO#")
    po_date = fields.Date("PO Date")
    uom = fields.Char("UOM")
    rig = fields.Char("Rig#")
    rate = fields.Float("Rate")
    qty_ordered = fields.Float("Qty Ordered")
    qty_delivered = fields.Float("Qty Delivered")
    balance_qty = fields.Float("Balance Qty")
    amount = fields.Float("Amount")
    remark = fields.Text("REMARK")
    availability = fields.Char("Availability")
    inv_no = fields.Char("INv No")
    inv_date = fields.Date("INv Date")


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    entry_date = fields.Date('Entry Date', default=datetime.today())






