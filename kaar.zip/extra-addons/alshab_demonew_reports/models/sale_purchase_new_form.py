from odoo import models,fields,api

class NewSalePurchaseForm(models.Model):
    _name = 'new.sale.purchase.form'

    company_id = fields.Many2one('res.company',"Company ID")
    product_id = fields.Many2one('product.product',"Product ID")
    sale_qty = fields.Char("Sale Qty")
    purchase_qty = fields.Char("Purchase Qty")
    sale_price = fields.Float("Sale Price")
    purchase_price = fields.Float("Purchase Price")
    sale_price_subtotal = fields.Float("Sale Price Subtotal")
    purchase_price_subtotal = fields.Float("Purchase Price Subtotal")
    profit = fields.Integer("Profit", compute="compute_profit")
    move_ids = fields.Many2many('account.move',"move_ids_rel")

    def compute_profit(self):
        for i in self:
            i.profit = i.sale_price_subtotal - i.purchase_price_subtotal

class AccountMove(models.Model):
    _inherit = "account.move"

    def action_post(self):
        res = super(AccountMove, self).action_post()
        if self.move_type =='out_invoice':
            for i in self.invoice_line_ids:
                check = self.env['new.sale.purchase.form'].search([('product_id', '=', i.product_id.id)])
                if check:
                    check.update({
                        'sale_qty': i.quantity,
                        'sale_price': i.price_unit,
                        'sale_price_subtotal': i.price_subtotal
                    })
                else:
                    self.env['new.sale.purchase.form'].create({
                         'company_id': self.company_id.id,
                         'product_id': i.product_id.id,
                         'sale_qty': i.quantity,
                         'sale_price': i.price_unit,
                         'sale_price_subtotal': i.price_subtotal,
                         'move_ids': [(6, 0, self.ids)]
                    })
        if self.move_type =='in_invoice':
            for i in self.invoice_line_ids:
                id = self.env['new.sale.purchase.form'].search([('product_id', '=', i.product_id.id)])
                if id:
                    id.update({
                        'purchase_qty': i.quantity,
                        'purchase_price': i.price_unit,
                        'purchase_price_subtotal': i.price_subtotal
                    })
                else:
                    self.env['new.sale.purchase.form'].create({
                        'company_id': self.company_id.id,
                        'product_id': i.product_id.id,
                        'purchase_qty': i.quantity,
                        'purchase_price': i.price_unit,
                        'purchase_price_subtotal': i.price_subtotal,
                        'move_ids': [(6, 0, self.ids)]


                    })
        return res











