from odoo import models,fields,api

class ImportPurchaseReport(models.Model):
    _name = 'import.purchase.report'

    from_date = fields.Date("From Date")
    to_date = fields.Date("to Date")
    purchase =fields.One2many('import.purchase','conn')

    @api.onchange('from_date', 'to_date', 'type')
    def onchange_purchase_report(self):
        fiscal = self.env['account.fiscal.position'].search([('name', '=', 'Import')])

        sales = self.env['purchase.order'].search(
            [('entry_date', '>=', self.from_date), ('entry_date', '<=', self.to_date),('fiscal_position_id', '=',fiscal.id)])

        form = []
        for i in sales:
            for prod in i.order_line:
                for m in i.invoice_ids:
                        values = (0, 0, {
                            'entry_date': i.entry_date,
                            'system_date': i.entry_date,
                            'supplier_name': i.partner_id.name,
                            'purchase_order_no': i.name,
                            'inv_no': m.name,
                            'inv_date': i.entry_date,
                            'inv_value': i.amount_total,
                            'converted_currency_amnt': i.convert_currency_amnt,
                            'currency': i.currency,
                            'airway_shipping_billno':i.airway_shipping_billno,
                            'custom_duty':i.custom_duty,
                            'vat_on_customs_duty':i.vat_on_customs_duty,
                            'freight':i.freight,
                            'processing_charge':i.processing_charge,
                            'vat_on_processing_charge':i.vat_on_processing_charge

                        })
                        form.append(values)
                        self.purchase = None
                        self.purchase = form



class ImportPurchase(models.Model):
    _name = 'import.purchase'
    conn = fields.Many2one('import.purchase.report')
    entry_date = fields.Date("Entry Date")
    system_date = fields.Date("System Date")
    supplier_name = fields.Char("Suplier Name")
    purchase_order_no = fields.Char("PO No")
    inv_no = fields.Char("INv No")
    inv_date = fields.Date("INV Date")
    inv_value = fields.Char("INv Value")
    converted_currency_amnt = fields.Float("Converted Currency Amnt")
    currency = fields.Char("Currency")
    airway_shipping_billno = fields.Char("Airway Shipping BillNo")
    custom_duty = fields.Char("Custom Duty")
    vat_on_customs_duty = fields.Char("VAt On Custom Duty")
    freight = fields.Char("Freight")
    processing_charge = fields.Char("Processing Charge")
    vat_on_processing_charge = fields.Char("Vat On Processing Charge")

class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    convert_currency_amnt = fields.Float("Converted Currency Amnt")
    currency = fields.Char("Currency")
    airway_shipping_billno = fields.Char("Airway Shipping BillNo")
    custom_duty = fields.Char("Custom Duty")
    vat_on_customs_duty = fields.Char("VAt On Custom Duty")
    freight = fields.Char("Freight")
    processing_charge = fields.Char("Processing Charge")
    vat_on_processing_charge = fields.Char("Vat On Processing Charge")
