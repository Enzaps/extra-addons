from odoo import models,fields,api

class PaymentCreditor(models.Model):
    _name = 'payment.creditor'

    from_date = fields.Date("From Date")
    to_date = fields.Date("To date")
    credit = fields.One2many('payment.to.creditor','conn')

    @api.onchange('from_date', 'to_date')
    def onchange_debit_note(self):
        datas = self.env['account.move'].search(
            [('invoice_date', '>=', self.from_date), ('invoice_date', '<=', self.to_date),
             ('move_type', '=', 'out_refund')])
        data = []
        for line in datas:
            values = (0, 0, {
                'date': line.invoice_date,
                'inv_no': line.name,
                'party_name': line.partner_id.name,
                'amount_paid': line.amount_total,
                'bill_due_date': line.invoice_date_due,
                'balance_outstanding': line.amount_residual
            })
            data.append(values)
        self.credit = None
        self.credit = data

class PaymentToCreditor(models.Model):
    _name = 'payment.to.creditor'

    conn = fields.Many2one('payment.creditor')
    date = fields.Date("Date")
    inv_no = fields.Char("INV No")
    party_name = fields.Char("Party Name")
    amount_paid = fields.Float("Amount Paid")
    bill_due_date = fields.Date("Bill Due Date")
    balance_outstanding = fields.Char("Balance Outstanding")