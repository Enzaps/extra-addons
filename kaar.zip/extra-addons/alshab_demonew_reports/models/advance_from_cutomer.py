from odoo import models,fields,api


class AdvanceCustomer(models.Model):
    _name = 'advance.customer'

    from_date = fields.Date("From Date")
    to_date = fields.Date("To date")
    advance = fields.One2many('advance.from.customer','conn')

    @api.onchange('from_date', 'to_date')
    def onchange_advance_payment(self):
        datas = self.env['sale.order'].search(
            [('entry_date', '>=', self.from_date), ('entry_date', '<=', self.to_date),('amnt_received_in_advance', '!=', 0.0)])
        data = []
        for line in datas:
            # for i in line.order_line:
                values = (0, 0, {
                    'date': line.entry_date,
                    'party_name': line.partner_id.name,
                    'so_no': line.name,
                    'so_date': line.entry_date,
                    'qty_ordered': sum(line.mapped('order_line').mapped('product_uom_qty')),
                    'rate': sum(line.mapped('order_line').mapped('price_unit')),
                    'tot_amnt':line.amount_total,
                    'amnt_received_in_advance':line.amnt_received_in_advance,
                    'due_date':line.po_date
                })
                data.append(values)
        self.advance = None
        self.advance = data


class AdvanceFromCutomer(models.Model):
    _name = 'advance.from.customer'

    conn = fields.Many2one('advance.customer')
    date = fields.Date("Date")
    party_name = fields.Char("Party Name")
    so_no = fields.Char("So No")
    so_date = fields.Date("So Date")
    qty_ordered = fields.Char("Qty Ordered")
    rate = fields.Float("Rate")
    tot_amnt = fields.Float("Tot Amnt")
    amnt_received_in_advance = fields.Float("Amnt Received In Advance")
    due_date = fields.Date("Due Date")

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    amnt_received_in_advance = fields.Float("Amnt Received In Advance")

class AccountPayment(models.Model):
    _inherit = 'account.payment'

    def action_post(self):
        res = super(AccountPayment, self).action_post()
        if self.sale_order_id:
            self.sale_order_id.amnt_received_in_advance = self.amount
        else:
         return res

