from odoo import models,fields,api

class NonInvoice(models.Model):
    _name = 'non.invoice'

    from_date = fields.Date("From Date")
    to_date = fields.Date("To date")
    non = fields.One2many('non.invoice.report','conn')

    @api.onchange('from_date', 'to_date')
    def onchange_from_date(self):
            datas = self.env['sale.order'].search(
                [('entry_date', '>=', self.from_date), ('entry_date', '<=', self.to_date),('invoice_ids', '=', False)])
            stockpicking = self.env['sale.order'].search(
                [('entry_date', '>=', self.from_date), ('entry_date', '<=', self.to_date),('invoice_ids', '=', False)]).picking_ids
            data = []
            for line in datas:
                stockpicking_id = line.mapped('picking_ids')
                for m in line.order_line:
                    values = (0, 0, {
                        'sl_no': m.serial_number,
                        'item_name': m.product_id.name,
                        'qty': m.product_uom_qty,
                        'selling_rate': m.price_unit,
                        'so_no': line.name,
                        'so_date': line.entry_date,
                        'customer_name': line.partner_id.name,
                        'customer_po': line.client_order_ref,
                        'dn_num': stockpicking_id.name,
                        'dn_date': line.po_date,
                    })
                    data.append(values)
                self.non = None
                self.non = data

class NonInvoiceReport(models.Model):
    _name = 'non.invoice.report'

    conn = fields.Many2one('non.invoice')
    sl_no = fields.Char("Sl No")
    item_name = fields.Char('Item Name')
    qty = fields.Char("Qty")
    selling_rate = fields.Char("Selling Rate")
    so_no = fields.Char("So No")
    so_date = fields.Date("So Date")
    customer_name = fields.Char("Customer Name")
    customer_po = fields.Char("Customer Po")
    dn_num = fields.Char("DN No")
    dn_date = fields.Date("DN Date")