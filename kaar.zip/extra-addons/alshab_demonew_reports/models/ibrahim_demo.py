from odoo import fields, models, api

try:
    import qrcode
except ImportError:
    qrcode = None


# import convert_numbers

class AccountMoveLine(models.Model):
    _inherit = "account.move.line"

    ar_qty = fields.Char("Ar Qty")
    ar_unit_price = fields.Char("Ar Unit Price")
    ar_total = fields.Char("Ar Total")
    ar_tax = fields.Char("Ar Tax")

    def price_subtotal_calculation(self):
        total_price = 0.00
        for inv in self:
            if inv.discount != 0.00:
                total_price = inv.quantity * inv.price_unit
            else:
                total_price = inv.quantity * inv.price_unit
        return total_price

    def tax_gst_calculation(self):
        vat_price = 0.00
        for inv in self:
            if inv.discount != 0.00:
                total_price = inv.quantity * inv.price_unit
                tax_value = self.env["account.tax"].search([('name', '=', inv.tax_ids.name)])
                for i in tax_value:
                    vat_price = (total_price * i.amount) / 100
                return vat_price
            else:
                total_price = inv.price_subtotal
                tax_value = self.env["account.tax"].search([('name', '=', inv.tax_ids.name)])
                for i in tax_value:
                    vat_price = (total_price * i.amount) / 100
                return vat_price

    def price_calculation(self):
        net_price = 0.00
        for inv in self:
            if inv.discount != 0.00:
                total_price = inv.quantity * inv.price_unit
                if inv.tax_ids:
                    tax_value = self.env["account.tax"].search([('name', '=', inv.tax_ids.name)])
                    for i in tax_value:
                        vat_price = (total_price * i.amount) / 100
                        net_price = total_price + vat_price
                    return net_price
                else:
                    vat_price = 0.00
                    net_price = total_price + vat_price
                    return net_price

            else:
                total_price = inv.price_subtotal
                if inv.tax_ids:

                    tax_value = self.env["account.tax"].search([('name', '=', inv.tax_ids.name)])
                    for i in tax_value:
                        vat_price = (total_price * i.amount) / 100
                        net_price = total_price + vat_price

                    return net_price
                else:
                    vat_price = 0.00
                    net_price = total_price + vat_price
                    return net_price

    def net_price_calculation(self):
        tax_value = 0.00
        tax_amount = 0.00
        for i in self:
            tax_value = self.env["account.tax"].search([('name', '=', self.tax_ids.name)])

            for tax in tax_value:
                tax_amount = (self.price_subtotal * tax.amount) / 100
            net_price_calculation = tax_amount + self.price_subtotal
        return tax_value

    def tax_calculation(self):
        tax_amount = 0.00
        name = []
        if self.tax_ids:
            tax_value = self.env["account.tax"].search(
                [('name', '=', self.tax_ids.name), ('type_tax_use', '=', 'sale')])
            for tax in tax_value:
                tax_amount = tax.amount
                return int(tax_amount)


        else:
            return tax_amount


class InvoiceInherit(models.Model):
    _inherit = "account.move"

    customer_id = fields.Char("Customer ID")
    ar_customer_id = fields.Char("Ar Customer ID")
    ar_invoice_no = fields.Char("Ar Invoice No")

    def amount_untaxed_calc(self):
        total_price = 0.00
        for inv in self.invoice_line_ids:
            if inv.discount != 0.00:
                total_price += inv.quantity * inv.price_unit
            else:
                total_price = 0.00
        return total_price

    def discount_calculation(self):
        discount = 0.00
        for dis in self.invoice_line_ids:
            if dis.discount != 0.00:
                total_price = dis.quantity * dis.price_unit
                discount += total_price * dis.discount / 100
            # else:
            #     discount += 0.00
        return discount

    def convert_number_arabic(self):
        print('jjjj')

    def convertion_amount(self):
        sale_amount_total_words = self.currency_id.amount_to_text(self.amount_total)
        return self.currency_id.amount_to_text(self.amount_total)
