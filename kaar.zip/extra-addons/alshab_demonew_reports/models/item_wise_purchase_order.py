from odoo import models,fields,api,_
from datetime import datetime

class ItemWise(models.Model):
    _name = 'item.wise'

    from_date = fields.Date("From Date")
    to_date = fields.Date("To Date")
    item = fields.One2many('item.wise.report','conn')

    @api.onchange('from_date', 'to_date', 'type')
    def onchange_item_wise(self):
        sales = self.env['stock.picking'].search(
            [('entry_date', '>=', self.from_date), ('entry_date', '<=', self.to_date),
             ('picking_type_code', '=', 'incoming')])
        form = []
        for note in sales:
            for i in note.purchase_id:
                for m in i.order_line:
                    for j in i.invoice_ids:
                        values = (0, 0, {
                            'date': i.entry_date,
                            'purchase_order_no':i.name,
                            'party_name': i.partner_id.name,
                            'date_of_purchase': i.entry_date,
                            'inv_no':j.name,
                            'supplier_name':i.partner_id.name,
                            'taxable_amnt': i.amount_untaxed,
                            'input_vat': i.amount_tax,
                            'gross_amnt': i.amount_total

                        })
                        form.append(values)
                        self.item = None
                        self.item = form


class ItemWiseReport(models.Model):
    _name = 'item.wise.report'

    conn = fields.Many2one('item.wise')
    date = fields.Date("Date")
    purchase_order_no = fields.Char("PO No")
    party_name = fields.Char("Party Name")
    date_of_purchase = fields.Date("Date Of Purchase")
    inv_no = fields.Char("INV No")
    supplier_name = fields.Char("Supplier Name")
    taxable_amnt = fields.Float("Taxable Amnt")
    input_vat = fields.Float("Input Vat")
    gross_amnt = fields.Float("Gross Amnt")

class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    entry_date = fields.Date('Entry Date', default=datetime.today())
