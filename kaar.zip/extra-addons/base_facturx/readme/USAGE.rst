This module doesn't do anything by itself, but it is used by 2 other modules:

* *account_invoice_facturx* that generate Factur-X 1.0 (i.e. ZUGFeRD 2.1) customer invoices/refunds,
* *account_invoice_import_facturx* that imports ZUGFeRD/Factur-X supplier invoices/refunds (all versions, including ZUGFeRD 1.0).
