This module adds a new object *account.payment.mode*, that is used to better
classify and route incoming/outgoing payment orders with the banks.
