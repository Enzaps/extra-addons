# -*- coding: utf-8 -*-
{
    'name': "Kar Bank Details",
    'summary': """
        Bank Details
        """,
    'description': """
       Bank Details
    """,
    'author': "Enzapps",
    'website': 'https://www.enzapps.com',
    'license': 'OPL-1',
    'version': '14.0.1.0.0',
    'category': 'Invoicing Management',
    'images': ['static/description/banner.jpg'],
    'depends': [
        'base',
        'account',
    ],
    'data': [
        'views/account_move.xml'
    ],
    'price': '0',
    'currency': 'EUR',

}
