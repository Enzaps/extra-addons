#. Go to the menu *Accounting > Configuration > Accounting > Taxes*
#. Set the field *UNECE Type Code* (the value should be *VAT* for most of your
   taxes).
#. Set the field *UNECE Category Code*.

There are localization modules that fill this information for specific chart
of accounts, so this step shouldn't be needed if installed.
