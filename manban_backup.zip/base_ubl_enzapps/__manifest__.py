# © 2016-2017 Akretion (Alexis de Lattre <alexis.delattre@akretion.com>)
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

{
    "name": "Base UBL Enzapps",
    "version": "14.0.1.1.0",
    "category": "Hidden",
    "license": "AGPL-3",
    "summary": "Base module for Universal Business Language (UBL)",
    "author": "Enzapps",
    "website": "https://enzapps.com",
    "depends": ["uom_unece","base_vat","base_ubl"],
    "external_dependencies": {"python": ["PyPDF2"]},
    "installable": True,
}
