* Alexis de Lattre <alexis.delattre@akretion.com>
* Andrea Stirpe <a.stirpe@onestein.nl>
* Levent Karakaş
* Pedro M. Baeza
