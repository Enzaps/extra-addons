Provide EDI exchange templates to control input/output records contents.

Provides following models:

1. EDI exchange output template, generates output using QWeb templates
2. [TODO] EDI exchange input template
