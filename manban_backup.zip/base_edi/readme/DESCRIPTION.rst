Base EDI module to aggregate EDI features.

Currently it provides:

1. home menu item
2. general security group
3. module category
