# -*- coding: utf-8 -*-
{
    'name': "Delivery Note Report",
    'author':
        'ENZAPPS',
    'summary': """
This module is for printing E-Invoice report for Masar Arabia.
""",

    'description': """
        This module is for printing E-Invoice report for Masar Arabia.
    """,
    'website': "",
    'category': 'base',
    'version': '12.0',
    'depends': ['base','account','sale','purchase','stock','arabic_numbers','arabic_strings',],
    'data': [
            'views/delivery.xml',
            'reports/reports.xml',
            'reports/delivery_note.xml',
    ],
    'demo': [
    ],
    'installable': True,
    'application': True,
}
