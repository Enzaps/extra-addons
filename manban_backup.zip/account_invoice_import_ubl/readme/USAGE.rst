Refer to the usage section of the module *account_invoice_import*.
