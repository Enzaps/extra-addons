# -*- coding: utf-8 -*-
{
    'name': "Change Type Of Delivery",
    'author':
        'Enzapps',
    'summary': """
This module is for Changing Type Of Delivery.
""",

    'description': """
            This module is for Changing Type Of Delivery.
    """,
    'website': "",
    'category': 'base',
    'version': '12.0',
    'depends': ['base', 'account', 'stock', 'product', 'sale', 'sale_management', 'purchase', 'contacts'],
    "images": ['static/description/icon.png'],
    'data': [
        
    ],
    'demo': [
    ],
    'installable': True,
    'application': True,
}
