Before installing the module, you must **uninstall** the module **account_edi** from the official addons. As the account_edi module is auto-installable, it is certainly already installed on your Odoo database.

For that, go to the *Apps* menu, remove the *Apps* filter, search for the module *account_edi* (the title of the module is *Import/Export Invoices From XML/PDF*). Then click on the button *Module info* and then on the button *Uninstall*.
