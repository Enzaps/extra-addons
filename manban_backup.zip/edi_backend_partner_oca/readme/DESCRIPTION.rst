This module add the a "Partner" field in EDI backend, this can be useful in
some situation in which a backend is restricted to only a given partner or
to have another criteria to search edi backends.
