* Alexis de Lattre <alexis.delattre@akretion.com>
* Andrea Stirpe <a.stirpe@onestein.nl>
* Jacques-Etienne Baudoux <je@bcim.be>
* Phuc (Tran Thanh) <phuc@trobz.com>
