In the menu *Invoicing > Configuration > Settings > Invoicing*, under
*Electronic Invoices*, check the value of 2 options:

* *XML Format embedded in PDF invoice* : if you want to have an UBL XML file
   embedded inside the PDF invoice, set it to
   *Universal Business Language (UBL)*
* if you work directly with XML invoices and you want to have the PDF invoice
  in base64 inside the XML file, enable the *Embed PDF in UBL XML Invoice*.
